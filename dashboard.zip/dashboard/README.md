# Dashboard — Offline Viewer

## Quick Start

1. Unzip this folder anywhere on your computer.
2. Open `index.html` in any modern browser (Chrome, Firefox, Edge, Safari).
3. The first open requires internet — the browser fetches and caches React & Recharts from unpkg CDN automatically.
4. From that point on the dashboard works fully offline.

## File Structure

```
dashboard/
├── index.html          ← Open this in your browser
├── css/
│   └── styles.css      ← All layout, cards, typography, responsive rules
├── js/
│   └── dashboard.js    ← All components, data, and chart logic
└── README.md
```

## Fully Air-Gapped (No Internet At All)

If you need zero network access, manually download these four files and place them in `js/libs/`:

| File | URL |
|------|-----|
| `react.production.min.js`     | https://unpkg.com/react@18/umd/react.production.min.js |
| `react-dom.production.min.js` | https://unpkg.com/react-dom@18/umd/react-dom.production.min.js |
| `prop-types.min.js`           | https://unpkg.com/prop-types@15/prop-types.min.js |
| `recharts.umd.min.js`         | https://unpkg.com/recharts@2/umd/Recharts.js |

Then update the four `<script src="...">` lines in `index.html` to point to your local copies:

```html
<script src="js/libs/react.production.min.js"></script>
<script src="js/libs/react-dom.production.min.js"></script>
<script src="js/libs/prop-types.min.js"></script>
<script src="js/libs/recharts.umd.min.js"></script>
```

## Editing the Dashboard

- **Data** — edit the arrays at the top of `js/dashboard.js`
- **Styles** — edit `css/styles.css`
- **Layout/Components** — edit the component functions in `js/dashboard.js`

No build tools or Node.js required.
