// ── Colour palette ────────────────────────────────────────────────────────────
const C = {
  blue:   "#3b82f6",
  green:  "#22c55e",
  amber:  "#f59e0b",
  purple: "#8b5cf6",
  indigo: "#6366f1",
  orange: "#f97316",
  text:   "#e5e5e5",
  muted:  "#888",
  dim:    "#555",
};

// ── Data ──────────────────────────────────────────────────────────────────────
const modelData = [
  { metric: "Accuracy",  centralized: 76.01, federated: 77.71 },
  { metric: "F1 Score",  centralized: 60.33, federated: 61.33 },
  { metric: "Precision", centralized: 53.77, federated: 56.85 },
  { metric: "Recall",    centralized: 68.72, federated: 66.58 },
];

const kfoldData = [
  { metric: "Accuracy",  centralized: 76.01, federated: 77.71 },
  { metric: "F1 Score",  centralized: 60.33, federated: 59.20 },
  { metric: "Precision", centralized: 55.10, federated: 56.30 },
  { metric: "Recall",    centralized: 66.20, federated: 62.80 },
];

const churnData = [
  { name: "Retained", value: 5174, pct: 73.5, color: C.green },
  { name: "Churned",  value: 1869, pct: 26.5, color: C.amber },
];

const featureData = [
  { feature: "TotalCharges",    importance: 14.2 },
  { feature: "MonthlyCharges",  importance: 12.8 },
  { feature: "tenure",          importance: 11.5 },
  { feature: "Contract",        importance:  9.8 },
  { feature: "PaperlessBilling",importance:  8.1 },
  { feature: "PaymentMethod",   importance:  7.9 },
  { feature: "OnlineSecurity",  importance:  7.2 },
  { feature: "TechSupport",     importance:  6.8 },
  { feature: "InternetService", importance:  6.5 },
];

const clients = [
  { id: 1, samples: 1878, churnRate: 26.4 },
  { id: 2, samples: 1878, churnRate: 26.7 },
  { id: 3, samples: 1878, churnRate: 26.3 },
];

const findingsItems = [
  { color: C.green, text: "Federated model achieves similar accuracy while preserving data privacy across all clients" },
  { color: C.green, text: "8% reduction in false positive rate compared to centralized training" },
  { color: C.blue,  text: "Centralized shows slightly better recall for actual churn cases" },
  { color: C.amber, text: "Class imbalance remains a challenge for both approaches" },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const { createElement: h, useState, useEffect, useRef } = React;
const {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie,
} = Recharts;

// ── MetricCard ────────────────────────────────────────────────────────────────
function MetricCard({ label, value, highlight, trend }) {
  return h("div", { className: "metric-card" },
    h("span", { className: "metric-label" }, label),
    h("div", { className: "metric-value-row" },
      h("span", { className: `metric-value${highlight ? " highlight" : ""}` }, value),
      trend && h("span", {
        className: `metric-trend ${trend.direction === "up" ? "up" : "down"}`
      }, `${trend.direction === "up" ? "▲" : "▼"} ${trend.value}%`)
    )
  );
}

// ── ChartCard ─────────────────────────────────────────────────────────────────
function ChartCard({ title, legend, children }) {
  return h("div", { className: "card" },
    h("div", { className: "chart-card-header" },
      h("p", { className: "chart-card-title" }, title),
      legend && h("div", { className: "chart-legend" },
        ...legend.map(({ color, label }) =>
          h("div", { className: "legend-item", key: label },
            h("span", { className: "legend-dot", style: { background: color } }),
            label
          )
        )
      )
    ),
    children
  );
}

// ── Bar Tooltip ───────────────────────────────────────────────────────────────
function BarTooltip({ active, payload, nameMap }) {
  if (!active || !payload?.length) return null;
  return h("div", { className: "tooltip-box" },
    h("p", { className: "tooltip-title" }, payload[0]?.payload?.metric),
    ...payload.map((p, i) =>
      h("p", { className: "tooltip-line", key: i },
        `${nameMap?.[p.name] ?? p.name}: ${Number(p.value).toFixed(1)}%`
      )
    )
  );
}

// ── Model Comparison Chart ────────────────────────────────────────────────────
function ModelComparisonChart() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const nameMap = { centralized: "Centralized", federated: "Federated" };
  return h(ChartCard, {
    title: "Model Comparison",
    legend: [{ color: C.blue, label: "Centralized" }, { color: C.green, label: "Federated" }],
  },
    h("div", { style: { height: 220 } },
      mounted && h(ResponsiveContainer, { width: "100%", height: 220 },
        h(BarChart, { data: modelData, barGap: 3, barCategoryGap: "22%" },
          h(XAxis, { dataKey: "metric", tick: { fill: C.dim, fontSize: 11 }, tickLine: false, axisLine: false }),
          h(YAxis, { domain: [50, 85], tick: { fill: C.dim, fontSize: 11 }, tickLine: false, axisLine: false, width: 32 }),
          h(Tooltip, { cursor: { fill: "rgba(255,255,255,0.02)" }, content: (p) => h(BarTooltip, { ...p, nameMap }) }),
          h(Bar, { dataKey: "centralized", radius: [3,3,0,0], maxBarSize: 22, fill: C.blue }),
          h(Bar, { dataKey: "federated",   radius: [3,3,0,0], maxBarSize: 22, fill: C.green })
        )
      )
    )
  );
}

// ── KFold Chart ───────────────────────────────────────────────────────────────
function KFoldBarChart() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const nameMap = { centralized: "Centralized KFold", federated: "Federated KFold" };
  return h(ChartCard, {
    title: "KFold Cross Validation — Metric Comparison",
    legend: [{ color: C.blue, label: "Centralized KFold" }, { color: C.orange, label: "Federated KFold" }],
  },
    h("div", { style: { height: 220 } },
      mounted && h(ResponsiveContainer, { width: "100%", height: 220 },
        h(BarChart, { data: kfoldData, barGap: 4, barCategoryGap: "24%" },
          h(XAxis, { dataKey: "metric", tick: { fill: C.dim, fontSize: 11 }, tickLine: false, axisLine: false }),
          h(YAxis, { domain: [50, 85], tick: { fill: C.dim, fontSize: 11 }, tickLine: false, axisLine: false, width: 32, tickFormatter: v => `${v}%` }),
          h(Tooltip, { cursor: { fill: "rgba(255,255,255,0.02)" }, content: (p) => h(BarTooltip, { ...p, nameMap }) }),
          h(Bar, { dataKey: "centralized", radius: [3,3,0,0], maxBarSize: 24, fill: C.blue }),
          h(Bar, { dataKey: "federated",   radius: [3,3,0,0], maxBarSize: 24, fill: C.orange })
        )
      )
    )
  );
}

// ── Confusion Matrix ──────────────────────────────────────────────────────────
function ConfusionMatrix({ title, subtitle, matrix, color }) {
  const total    = matrix.tn + matrix.fp + matrix.fn + matrix.tp;
  const accuracy = ((matrix.tn + matrix.tp) / total * 100).toFixed(1);
  const maxVal   = Math.max(matrix.tn, matrix.fp, matrix.fn, matrix.tp);
  const opacity  = v => Math.max(0.12, v / maxVal * 0.65);
  const cells    = [
    { v: matrix.tn, label: "TN" }, { v: matrix.fp, label: "FP" },
    { v: matrix.fn, label: "FN" }, { v: matrix.tp, label: "TP" },
  ];

  return h("div", { className: "confusion-card" },
    h("div", null,
      h("p", { className: "confusion-title" }, title),
      h("p", { className: "confusion-subtitle" }, subtitle)
    ),
    h("div", { className: "confusion-body" },
      h("p", { className: "confusion-axis-label" }, "Predicted"),
      h("div", { className: "confusion-row" },
        h("p", { className: "confusion-y-label" }, "Actual"),
        h("div", null,
          h("div", { className: "confusion-grid-header" },
            h("span", null, "No"), h("span", null, "Yes")
          ),
          h("div", { className: "confusion-grid" },
            ...cells.map(({ v, label }) =>
              h("div", {
                key: label,
                className: "confusion-cell",
                style: { backgroundColor: `rgba(${color}, ${opacity(v)})` }
              },
                h("span", { className: "confusion-cell-value" }, v),
                h("span", { className: "confusion-cell-label" }, label)
              )
            )
          )
        )
      ),
      h("div", { className: "confusion-accuracy" },
        "Accuracy: ", h("span", null, `${accuracy}%`)
      )
    )
  );
}

// ── Key Findings ──────────────────────────────────────────────────────────────
function FindingsCard() {
  return h("div", { className: "findings-card" },
    h("p", { className: "findings-title" }, "Key Findings"),
    h("div", { className: "findings-list" },
      ...findingsItems.map(({ color, text }, i) =>
        h("div", { className: "findings-item", key: i },
          h("span", { className: "findings-dot", style: { background: color } }),
          h("span", { className: "findings-text" }, text)
        )
      )
    )
  );
}

// ── Churn Chart ───────────────────────────────────────────────────────────────
function ChurnChart() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return h(ChartCard, { title: "Churn Distribution" },
    h("div", { style: { position: "relative", height: 180 } },
      mounted && h(ResponsiveContainer, { width: "100%", height: 180 },
        h(PieChart, null,
          h(Pie, {
            data: churnData, cx: "50%", cy: "50%",
            innerRadius: 52, outerRadius: 72, paddingAngle: 2,
            dataKey: "value", stroke: "none"
          },
            ...churnData.map((d, i) => h(Cell, { key: i, fill: d.color }))
          )
        )
      ),
      h("div", { className: "pie-center" },
        h("div", null,
          h("p", { className: "pie-center-value" }, "7,043"),
          h("p", { className: "pie-center-label" }, "Total")
        )
      )
    ),
    h("div", { className: "pie-legend" },
      ...churnData.map((d, i) =>
        h("div", { className: "pie-legend-item", key: i },
          h("span", { className: "pie-legend-dot", style: { background: d.color } }),
          `${d.name} ${d.pct}%`
        )
      )
    )
  );
}

// ── Feature Chart ─────────────────────────────────────────────────────────────
function FeatureChart() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return h(ChartCard, { title: "Feature Importance" },
    h("div", { style: { height: 220 } },
      mounted && h(ResponsiveContainer, { width: "100%", height: 220 },
        h(BarChart, { data: featureData, layout: "vertical", margin: { left: 0, right: 8, top: 0, bottom: 0 } },
          h(XAxis, {
            type: "number", tick: { fill: C.dim, fontSize: 10 },
            tickLine: false, axisLine: false, domain: [0, 16],
            tickFormatter: v => `${v}%`
          }),
          h(YAxis, {
            type: "category", dataKey: "feature",
            tick: { fill: C.muted, fontSize: 10 }, tickLine: false, axisLine: false, width: 100
          }),
          h(Tooltip, {
            cursor: { fill: "rgba(255,255,255,0.02)" },
            content: ({ active, payload }) => {
              if (!active || !payload?.length) return null;
              return h("div", { className: "tooltip-box" },
                h("p", { className: "tooltip-title" }, payload[0]?.payload?.feature),
                h("p", { className: "tooltip-line" }, `Importance: ${payload[0]?.value}%`)
              );
            }
          }),
          h(Bar, { dataKey: "importance", radius: [0,3,3,0], maxBarSize: 13 },
            ...featureData.map((_, i) =>
              h(Cell, {
                key: i,
                fill: i < 3 ? C.purple : C.indigo,
                fillOpacity: 1 - i * 0.08
              })
            )
          )
        )
      )
    )
  );
}

// ── Client Distribution ───────────────────────────────────────────────────────
function ClientDistribution() {
  return h("div", { className: "client-card" },
    h("p", { className: "client-title" }, "Client Distribution"),
    h("div", { className: "client-list" },
      ...clients.map(c =>
        h("div", { key: c.id },
          h("div", { className: "client-row" },
            h("span", { className: "client-name" }, `Client ${c.id}`),
            h("span", { className: "client-samples" }, `${c.samples.toLocaleString()} samples`)
          ),
          h("div", { className: "client-bar-bg" },
            h("div", { className: "client-bar-fill", style: { width: "100%" } })
          ),
          h("p", { className: "client-churn" }, `Churn rate: ${c.churnRate}%`)
        )
      )
    ),
    h("div", { className: "client-footer" },
      ...[ ["Train samples", "5,634"], ["Test samples", "1,409"] ].map(([k, v]) =>
        h("div", { className: "client-stat", key: k },
          h("span", { className: "client-stat-key" }, k),
          h("span", { className: "client-stat-val" }, v)
        )
      )
    )
  );
}

// ── SectionLabel ──────────────────────────────────────────────────────────────
function SectionLabel({ children }) {
  return h("p", { className: "section-label" }, children);
}

// ── Dashboard (root) ──────────────────────────────────────────────────────────
function Dashboard() {
  return h("div", null,
    h("header", null,
      h("div", { className: "header-inner" },
        h("h1", null, "Privacy-Preserving Customer Churn Prediction"),
        h("p", null, "Federated Learning on Distributed Data")
      )
    ),
    h("main", null,

      /* Metrics */
      h("div", { className: "section" },
        h("div", { className: "grid-6" },
          h(MetricCard, { label: "Total Samples", value: "7,043" }),
          h(MetricCard, { label: "Features",      value: "26" }),
          h(MetricCard, { label: "FL Clients",    value: "3" }),
          h(MetricCard, { label: "Churn Rate",    value: "26.5%", highlight: true }),
          h(MetricCard, { label: "Best Accuracy", value: "77.7%", trend: { value: 1.7, direction: "up" } }),
          h(MetricCard, { label: "Privacy",       value: "100%" })
        )
      ),

      /* Model Performance */
      h("div", { className: "section" },
        h(SectionLabel, null, "Model Performance"),
        h("div", { className: "grid-2" },
          h(ModelComparisonChart, null),
          h(KFoldBarChart, null)
        )
      ),

      /* Prediction Results */
      h("div", { className: "section" },
        h(SectionLabel, null, "Prediction Results"),
        h("div", { className: "grid-3" },
          h(ConfusionMatrix, {
            title: "Centralized Model", subtitle: "Traditional approach",
            matrix: { tn: 821, fp: 242, fn: 117, tp: 257 }, color: "59, 130, 246"
          }),
          h(ConfusionMatrix, {
            title: "Federated Model", subtitle: "Privacy-preserving",
            matrix: { tn: 840, fp: 223, fn: 125, tp: 249 }, color: "34, 197, 94"
          }),
          h(FindingsCard, null)
        )
      ),

      /* Data Analysis */
      h("div", { className: "section" },
        h(SectionLabel, null, "Data Analysis"),
        h("div", { className: "grid-3" },
          h(ChurnChart, null),
          h(FeatureChart, null),
          h(ClientDistribution, null)
        )
      )
    )
  );
}

// ── Mount ─────────────────────────────────────────────────────────────────────
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(h(Dashboard, null));
